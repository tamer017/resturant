
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../screen/category_meal_screen.dart';

class Category_Item extends StatelessWidget {
  final String id;
  final String title;
  final Color color;

  Category_Item({required this.id, required this.title, required this.color});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(30),
      onTap: () {
        Navigator.of(context).pushNamed(CategoryMealsScreen.route,
          arguments: {
          'id': id,
          'title' :title,
          'color' : color
        },);
      },
      splashColor: Theme.of(context).primaryColor,
      child: Container(
        alignment: Alignment.center,
        child: Text(
          title,
          style: Theme.of(context).textTheme.title,
        ),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          color: color,
          gradient: LinearGradient(
              colors: [color.withOpacity(0.5), color],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight),
        ),
      ),
    );
  }
}
