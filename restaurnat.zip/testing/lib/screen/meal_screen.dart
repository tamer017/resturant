import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import '../data.dart';
import '../models/meal.dart';

class MealScreen extends StatefulWidget {
  static final String route = "MealScreen";

  final Function setFavorite;
  final Function iconState;

  const MealScreen({required this.setFavorite,required this.iconState});

  @override
  _MealScreenState createState() => _MealScreenState();
}

class _MealScreenState extends State<MealScreen> {
  Widget textBuilder(String text, BuildContext context) {
    return Container(
      alignment: Alignment.center,
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Text(
        text,
        style: Theme.of(context).textTheme.title,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final String id = ModalRoute.of(context)!.settings.arguments as String;
    Meal meal = MEALS.firstWhere((meal) {
      return meal.id == id;
    });

    return Scaffold(
      appBar: AppBar(
        title: Container(width: 400, child: Text(meal.title)),
      ),
      body: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: double.infinity,
                child: Image.network(
                  meal.imageUrl,
                  fit: BoxFit.fill,
                ),
              ),
              textBuilder("Recipes", context),
              Container(
                padding: EdgeInsets.all(15),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Color.fromRGBO(255, 255, 0, 0.3),
                    border: Border.all(color: Colors.grey, width: 2.5)),
                height: 150,
                width: 300,
                child: ListView.builder(
                  itemBuilder: (BuildContext context, int index) {
                    return Card(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10.0, vertical: 5),
                          child: Text(
                            meal.ingredients[index],
                          ),
                        ),
                      ),
                    );
                  },
                  itemCount: meal.ingredients.length,
                ),
              ),
              textBuilder("Steps", context),
              Container(
                padding: EdgeInsets.all(15),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Color.fromRGBO(255, 255, 0, 0.3),
                    border: Border.all(color: Colors.grey, width: 2.5)),
                height: 200,
                width: 300,
                child: ListView.builder(
                  itemBuilder: (BuildContext context, int index) {
                    return Column(
                      children: [
                        DecoratedBox(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: ListTile(
                            leading: CircleAvatar(
                              backgroundColor: Theme.of(context).primaryColor,
                              radius: 15,
                              child: Text(
                                "${index + 1}",
                                style: TextStyle(
                                  color: Color.fromRGBO(236, 228, 39, 1.0),
                                ),
                              ),
                            ),
                            title: Text(
                              meal.steps[index],
                            ),
                          ),
                        ),
                        Divider(
                          thickness: 2.5,
                        ),
                      ],
                    );
                  },
                  itemCount: meal.steps.length,
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            widget.setFavorite(id);
          });
        },
        child: Icon(
          Icons.star,
          color: widget.iconState(id) ?Theme.of(context).accentColor:Colors.black87,
        ),
        backgroundColor: Theme.of(context).primaryColor,
      ),
    );
  }
}
