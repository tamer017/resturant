import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../screen/my_drawer.dart';

class FilterScreen extends StatefulWidget {
  static String route = "FilterScreen";
  final Function buildFilters;
  final Map<String, bool> filters;

  FilterScreen({required this.buildFilters, required this.filters});

  @override
  _FilterScreenState createState() => _FilterScreenState();
}

class _FilterScreenState extends State<FilterScreen> {
  bool _glutenFree = false;

  bool _lactoseFree = false;

  bool _vegan = false;

  bool _vegetarian = false;

  @override
  initState() {
    _glutenFree = (widget.filters["Gluten Free"]) as bool;

    _lactoseFree = (widget.filters["Lactose Free"]) as bool;

    _vegan = (widget.filters["Vegetarian"]) as bool;

    _vegetarian = (widget.filters["Vegan"]) as bool;
    super.initState();
  }

  Widget bulidSwitchListTile(
    String title,
    String subTitel,
    bool value,
    Function update,
  ) {
    return SwitchListTile(
      title: Text(
        title,
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
      subtitle: Text(subTitel),
      onChanged: (bool) {
        update(bool);
      },
      value: value,
      activeColor: Theme.of(context).primaryColor,
      inactiveThumbColor: Theme.of(context).accentColor,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("your filters"),
        actions: [
          IconButton(
            onPressed: () {
              setState(() {
                widget.buildFilters(
                  {
                    "Gluten Free": _glutenFree,
                    "Lactose Free": _lactoseFree,
                    "Vegetarian": _vegetarian,
                    "Vegan": _vegan,
                  },
                );
              });
            },
            icon: Icon(Icons.save),
          )
        ],
      ),
      body: Column(
        children: [
          Container(
            alignment: Alignment.center,
            padding: EdgeInsets.symmetric(vertical: 20),
            child: Text(
              "Adjust your meals selection",
              style: Theme.of(context).textTheme.title,
            ),
          ),
          Expanded(
            child: ListView(
              children: [
                bulidSwitchListTile(
                  "Gluten free",
                  "only include gluten free meals",
                  _glutenFree,
                  (bool value) {
                    setState(() {
                      _glutenFree = value;
                    });
                  },
                ),
                bulidSwitchListTile(
                  "Lactose free",
                  "only include lactose free meals",
                  _lactoseFree,
                  (bool value) {
                    setState(() {
                      _lactoseFree = value;
                    });
                  },
                ),
                bulidSwitchListTile(
                  "Vegetarian",
                  "only include vegetarian meals",
                  _vegetarian,
                  (bool value) {
                    setState(() {
                      _vegetarian = value;
                    });
                  },
                ),
                bulidSwitchListTile(
                  "Vegan",
                  "only include vegan meals",
                  _vegan,
                  (bool value) {
                    setState(() {
                      _vegan = value;
                    });
                  },
                ),
              ],
            ),
          )
        ],
      ),
      drawer: MyDrawer(),
    );
  }
}
