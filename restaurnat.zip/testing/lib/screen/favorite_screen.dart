import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../widgets/meal_item.dart';
import '../models/meal.dart';

class FavoriteScreen extends StatelessWidget {
  final List<Meal> fivoriteMeals;

  const FavoriteScreen({required this.fivoriteMeals,});

  @override
  Widget build(BuildContext context) {
    return fivoriteMeals.isEmpty
        ? Scaffold(
            body: Container(
              padding: EdgeInsets.all(15),
              alignment: Alignment.center,
              child: Text(
                "you have no favorite meals ... add your owen",
                style: Theme.of(context).textTheme.title,
              ),
            ),
          )
        : Scaffold(
            body: ListView.builder(
              itemBuilder: (BuildContext context, int index) {
                return MealItem(
                    id: fivoriteMeals[index].id,
                    title: fivoriteMeals[index].title,
                    imageUrl: fivoriteMeals[index].imageUrl,
                    duration: fivoriteMeals[index].duration,
                    complexity: fivoriteMeals[index].complexity,
                    affordability: fivoriteMeals[index].affordability);
              },
              itemCount: fivoriteMeals.length,
            ),
          );
  }
}
