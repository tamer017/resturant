import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../models/meal.dart';
import '../widgets/meal_item.dart';

import '../data.dart';

class CategoryMealsScreen extends StatefulWidget {
  static const route = "CategoryMealsScreen";
  final List<Meal> filteredMeals;

  CategoryMealsScreen({required this.filteredMeals});

  @override
  _CategoryMealsScreenState createState() => _CategoryMealsScreenState();
}

class _CategoryMealsScreenState extends State<CategoryMealsScreen> {
  String title = "";
  List<Meal> Meals =[];

  @override
  void didChangeDependencies() {
    final Map<String, Object> routeArg =
        ModalRoute.of(context)!.settings.arguments as Map<String, Object>;
    title = routeArg['title'] as String;
    var id = routeArg['id'];
    Meals = widget.filteredMeals.where((meal) {
      return meal.categories.contains(id);
    }).toList();
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView.builder(
        itemBuilder: (BuildContext context, int index) {
          return MealItem(
              id: Meals[index].id,
              title: Meals[index].title,
              imageUrl: Meals[index].imageUrl,
              duration: Meals[index].duration,
              complexity: Meals[index].complexity,
              affordability: Meals[index].affordability);
        },
        itemCount: Meals.length,
      ),
    );
  }


}
