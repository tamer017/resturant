import 'package:flutter/material.dart';
import '../models/meal.dart';
import '../screen/category_screen.dart';
import '../screen/favorite_screen.dart';

import 'my_drawer.dart';

class HomeScreen extends StatefulWidget {
  final List<Meal> fivoriteMeals;

  HomeScreen({required this.fivoriteMeals});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int currentIndex = 0;

  move(int index) {
    setState(() {
      currentIndex = index;
    });
  }

  List<Map<String, Object>> Screens = [];

  initState() {
    Screens = [
      {
        'widget': CategoryScreen(),
        'title': 'Categories',
      },
      {
        'widget': FavoriteScreen(
          fivoriteMeals: widget.fivoriteMeals,
        ),
        'title': 'favorite',
      }
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(Screens[currentIndex]['title'] as String),
      ),
      body: Screens[currentIndex]['widget'] as Widget,
      bottomNavigationBar: BottomNavigationBar(
        selectedItemColor: Theme.of(context).accentColor,
        currentIndex: currentIndex,
        onTap: move,
        type: BottomNavigationBarType.shifting,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.category_sharp),
            title: Text("Categories"),
            backgroundColor: Theme.of(context).primaryColor,
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.star),
            title: Text("Favorite"),
            backgroundColor: Theme.of(context).primaryColor,
          )
        ],
      ),
      drawer: MyDrawer(),
    );
  }
}
