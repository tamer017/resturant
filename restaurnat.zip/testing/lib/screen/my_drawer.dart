import 'filter_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class MyDrawer extends StatelessWidget {
  const MyDrawer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: [
          Container(
            alignment: Alignment.center,
            color: Theme.of(context).accentColor,
            height: 100,
            width: double.infinity,
            child: Text(
              "Cooking up!",
              style: TextStyle(
                fontWeight: FontWeight.w900,
                color: Theme.of(context).primaryColor,
                fontSize: 40,
              ),
            ),
          ),
          SizedBox(
            height: 30,
            width: double.infinity,
          ),
          buildListTile('Meals', Icons.restaurant,(){Navigator.of(context).pushReplacementNamed('/');}),
          buildListTile('Filter', Icons.settings,(){Navigator.of(context).pushReplacementNamed(FilterScreen.route);}),
        ],
      ),
    );
  }

  Widget buildListTile(String title, IconData icon,Function OnTap) {
    return ListTile(
      onTap: (){OnTap();},
      leading: Icon(
        icon,
        size: 30,
      ),
      title: Text(
        title,
        style: TextStyle(
          fontWeight: FontWeight.w700,
          fontSize: 30,
        ),
      ),
    );
  }
}
