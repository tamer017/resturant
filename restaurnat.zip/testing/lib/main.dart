import 'package:flutter/material.dart';
import '../models/meal.dart';
import '../screen/category_meal_screen.dart';
import '../screen/filter_screen.dart';
import '../screen/home_screen.dart';
import '../screen/meal_screen.dart';
import 'data.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  Map<String, bool> filters = {
    "Gluten Free": false,
    "Lactose Free": false,
    "Vegetarian": false,
    "Vegan": false
  };

  List<Meal> filteredMeals = MEALS;

  List<Meal> fivoriteMeals = [];

  setFavorite(String MealId) {
    setState(() {
      if (!fivoriteMeals.any((meal) => meal.id == MealId))
        fivoriteMeals.add(MEALS.firstWhere((meal) => meal.id == MealId));
      else
        fivoriteMeals.removeWhere((meal) => meal.id == MealId);
    });
  }

  bool iconState(String MealId) {
    return fivoriteMeals.any((meal) => meal.id == MealId);
  }

  buildFilters(Map<String, bool> selectedFilters) {
    filters = selectedFilters;
    filteredMeals = MEALS.where((meal) {
      if (!meal.isGlutenFree && (selectedFilters["Gluten Free"] as bool))
        return false;
      if (!meal.isLactoseFree && (selectedFilters["Lactose Free"] as bool))
        return false;
      if (!meal.isVegetarian && (selectedFilters["Vegetarian"] as bool))
        return false;
      if (!meal.isVegan && (selectedFilters["Vegan"] as bool)) return false;
      return true;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.pink,
        accentColor: Colors.amber,
        canvasColor: Color.fromRGBO(249, 195, 157, 1),
        textTheme: ThemeData().textTheme.copyWith(
              title: TextStyle(
                  fontFamily: "RobotoCondensed",
                  fontSize: 25,
                  fontWeight: FontWeight.bold),
            ),
      ),
      routes: {
        '/': (context) => HomeScreen(
              fivoriteMeals: fivoriteMeals,
            ),
        CategoryMealsScreen.route: (context) => CategoryMealsScreen(
              filteredMeals: filteredMeals,
            ),
        MealScreen.route: (context) =>
            MealScreen(setFavorite: setFavorite, iconState: iconState),
        FilterScreen.route: (context) =>
            FilterScreen(buildFilters: buildFilters, filters: filters)
      },
    );
  }
}
